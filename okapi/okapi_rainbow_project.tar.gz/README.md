# Instructions

This Rainbow project includes everything you need to re-create the [`XLIFF_bestpractices_OMT`](https://github.com/capstanlqc/XLIFF_bestpractices_OMT) OmegaT project (or the XLIFF files it contains). 

However, some local paths are saved in the project settings, which will most likely be different in your machine. Here are some steps you must follow to make up for that: 

1. Unpack the bundle (which you probably have already done if you're reading this).
2. Launch Okapi Rainbow and open the `rnb` file.
    - THere are three `rnb` files included, depending on whether you want to generate XLIFF 1.2 files, XLIFF 2.0 files or an OmegaT project (containing XLIFF 1.2 files).
3. Press F2 to edit the path to the project's root folder and paste there the path to the folder where you have unpacked the bundle that contains the present document, the `rnb` files, etc.
4. You might also need to edit the filter parameters and the custom configurations paths in the same way:
    - Go to **Other settings** > **Filters Parameters** > **...** and enter the same path to the root folder.
    - If the filter configuration is missing for any file, double click the filter configuration column for that file to open the **Input Document Properties**, then go to **More...** > **Custom Configurations** > **...** and proceed likewise.